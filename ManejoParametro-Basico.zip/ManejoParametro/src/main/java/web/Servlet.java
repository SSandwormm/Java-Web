package web;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet("/Servlet")
public class Servlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse reponse) throws IOException {
        //leer los parametros de html
        String usuario = request.getParameter("usuario");
        String password = request.getParameter("password");

        System.out.println("usuario = " + usuario);
        System.out.println("password = " + password);

        PrintWriter out = reponse.getWriter();
        out.print("<html>");
        out.print("<body>");
        out.print("el parametro usuario es: " + usuario);
        out.print("<br>");
        out.print("el parametro usuario es: " + password);
        out.print("</body>");
        out.print("</html>");
        out.close();

    }

}
